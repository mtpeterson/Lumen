// Pixel.cpp
#include <Arduino.h>
#include "Pixel.h"
// #include "Adafruit_NeoPixel.h"

// Pixel::Pixel(byte pin, byte pixelNumber, byte numberOfSparks) 
// {
//   pinMode(pin, OUTPUT);

//   _pin = pin;
//   _pixelNumber = pixelNumber;
//   _numberOfSparks = numberOfSparks;

//   byte redValues[_numberOfSparks];
//   // byte greenValues[_numberOfSparks];
//   // byte blueValues[_numberOfSparks];
//   _numberOfSparks = numberOfSparks;
//   redValues = new int[_numberOfSparks];
      
//   for(int i = 0; i < _numberOfSparks; i++) {
//     redValues[i] = 0;
//     // greenValues[i] = 0;
//     // blueValues[i] = 0;
//   }

  // Adafruit_NeoPixel strip(numPixels, Neopixels);
// }

// void Pixel::showPixels() {
//   redHigh = redValues[0];
//   greenHigh = greenValues[0];
//   blueHigh = blueValues[0];

//   for(int i = 0; i < _numberOfSparks; i++) {
//     redValues[i] = 0;
//     greenValues[i] = 0;
//     blueValues[i] = 0;
//   }

//   // strip.setPixelColor(_pixelNumber, showRed, showGreen, showBlue);
// }

byte Pixel::showRed() {
  redHigh = redValues[0];
  for(int i = 0; i < _numberOfSparks; i++) {
    redHigh = max(redValues[i], redHigh);
  }
  return redHigh;
}
byte Pixel::showGreen() {
  greenHigh = greenValues[0];
  for(int i = 0; i < _numberOfSparks; i++) {
    greenHigh = max(greenValues[i], greenHigh);
  }
  return greenHigh;
}
byte Pixel::showBlue() {
  blueHigh = redValues[0];
  for(int i = 0; i < _numberOfSparks; i++) {
    blueHigh = max(redValues[i], blueHigh);
  }
  return blueHigh;
}

void Pixel::accessRedArray(int index, byte value) {
  redValues[index] = value;
}
void Pixel::accessGreenArray(int index, byte value) {
  greenValues[index] = value;
}
void Pixel::accessBlueArray(int index, byte value) {
  blueValues[index] = value;
}

void Pixel::clearColorArrays() {
  for(int i = 0; i < _numberOfSparks; i++) {
    redHigh = max(redValues[i], redHigh);
    greenHigh = max(greenValues[i], greenHigh);
    blueHigh = max(blueValues[i], blueHigh);
  }  
}
// void Spark::showSpark(uint32_t color) {
  
// }
// void Spark::showSparkGlow(byte strength) {
  
// // }