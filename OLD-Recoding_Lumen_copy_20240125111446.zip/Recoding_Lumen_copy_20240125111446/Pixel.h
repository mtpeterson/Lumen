// Pixel.h
#ifndef Pixel_h
#define Pixel_h

#include <Arduino.h>
#include <Adafruit_NeoPixel.h>
#include "Spark.h"

class Pixel {
private:
  byte _pin;
  int _pixelNumber;
  int _numberOfSparks;

  byte* redValues;
  byte* greenValues;
  byte* blueValues;

  byte redHigh;
  byte greenHigh;
  byte blueHigh;
public:
  Pixel(int numberOfSparks) {

    // _pin = pin;
    // _pixelNumber = pixelNumber;
    _numberOfSparks = numberOfSparks;

    // pinMode(_pin, OUTPUT);
    
    redValues = new byte[_numberOfSparks];
    greenValues = new byte[_numberOfSparks];
    blueValues = new byte[_numberOfSparks];

    // for (int i = 0; i < _numberOfSparks; i++) {
    //   redValues[i] = 0;
    //   greenValues[i] = 0;
    //   blueValues[i] = 0;
    // }
  }
  // void showPixels();
  byte showRed();
  byte showGreen();
  byte showBlue();

  void accessRedArray(int index, byte value);
  void accessGreenArray(int index, byte value);
  void accessBlueArray(int index, byte value);

  void clearColorArrays();
};



#endif