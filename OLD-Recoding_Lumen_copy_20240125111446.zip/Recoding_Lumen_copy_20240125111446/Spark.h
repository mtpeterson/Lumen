// Spark.h
#ifndef Spark_h
#define Spark_h

#include <Arduino.h>
#include "Pixel.h"

class Spark {
  private:
    // byte _pin;
    uint32_t _color;
    int location;
    int SparkID;

  public:
    Spark(int SparkNumber, int startPixelNum, uint32_t color);
    int moveSpark(byte speed);
    void calculateGlow(byte strength);
    // void moveFrontGlow(byte strength);
    // void moveBackGlow(byte strength);

    // void showSpark();
    // void showSparkGlow(byte strength);
};
//was private

    // Pixel red;
    // Pixel green;
    // Pixel blue;


  // private:
  //   int ledPin;
  //   unsigned char ledState;

  // public:
  //   Spark(int pin);
  //   void turnON();
  //   void turnOFF();
  //   int getState();

#endif