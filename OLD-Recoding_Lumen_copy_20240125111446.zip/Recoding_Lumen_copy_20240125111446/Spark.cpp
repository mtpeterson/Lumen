// Spark.cpp
#include <Arduino.h>
#include "Spark.h"
#include "Pixel.h"

Spark::Spark(int SparkNumber, int startPixelNum, uint32_t color) {
  // pinMode(pin, OUTPUT);
  // _pin = pin;
  _color = color;
  //location will be 100 times the actual location, that way it can be updated in hundreths
  location = startPixelNum * 100;
  SparkID = SparkNumber;
}
int Spark::moveSpark(byte speed) {
  //does this work?? integer + byte
  location += speed;
  return (location / 100);
}
void Spark::calculateGlow(byte strength) {
  
}
// void Spark::showSpark(uint32_t color) {
  
// }
// void Spark::showSparkGlow(byte strength) {
  
// // }